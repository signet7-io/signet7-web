#!/bin/sh
set -eu
PREFIX="${PREFIX:-$HOME/.local/share/signet7}"
BIN="${BIN:-$HOME/.local/bin}"
rm -f "$BIN/signet7" "$BIN/signet7-agent" "$BIN/signet7-setup" "$BIN/signet7-email" "$BIN/signet7-verify"
rm -rf "$HOME/Applications/Signet7.app"
rm -rf "$PREFIX"
echo "uninstalled prefix=$PREFIX"
