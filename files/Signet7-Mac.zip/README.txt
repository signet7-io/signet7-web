Signet7 for macos

This installs the Signet7 app on one office computer.
People you email do not install it.

Open Terminal in this folder and run: sh ./install.sh
Mac may say the app was not opened. The certificate is not finished. Move to Trash is the other button. Do not use that.

The app is in the Signet7 folder. Leave that folder next to this file until install finishes.
