Signet7 for macos

This installs the Signet7 app on one office computer.
People you email do not install it.

Double-click Signet7.app.
On this Mac, an unverified app may only offer Move to Trash and Done. The certificate is not finished.

The app is in the Signet7 folder. Leave that folder next to this file until install finishes.
