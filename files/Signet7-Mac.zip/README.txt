Signet7

Double-click the setup. On Windows that file is signet7-setup.exe, inside the Signet7 folder.
On Mac, open Signet7.app.
Windows may say the publisher is unknown. On a Mac, the only choices may be Move to Trash and Done until a certificate is finished.
Uninstall is a button in the app.
People you email do not install this.
