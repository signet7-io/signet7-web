#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
SRC="$ROOT/Signet7"
PREFIX="${PREFIX:-$HOME/.local/share/signet7}"
BIN="${BIN:-$HOME/.local/bin}"
mkdir -p "$PREFIX" "$BIN"

for forbidden in Signet7-Server Signet7-MCP Signet7-Export Signet7-Restore Signet7-Anchor-Reconcile Signet7-Authenticated-History-Create Signet7-Authenticated-History-Verify; do
  if [ -e "$SRC/$forbidden" ] || [ -e "$SRC/${forbidden}.exe" ]; then
    echo "Operator binary is not allowed in the customer package: $forbidden" >&2
    exit 2
  fi
done

installed=0
if [ -d "$SRC/Signet7.app" ]; then
  mkdir -p "$HOME/Applications"
  rm -rf "$HOME/Applications/Signet7.app"
  cp -R "$SRC/Signet7.app" "$HOME/Applications/Signet7.app"
  ln -sfn "$HOME/Applications/Signet7.app/Contents/MacOS/Signet7" "$BIN/signet7"
  installed=1
fi
if [ -f "$SRC/signet7-agent" ]; then
  cp "$SRC/signet7-agent" "$PREFIX/signet7-agent"
  chmod +x "$PREFIX/signet7-agent"
  ln -sfn "$PREFIX/signet7-agent" "$BIN/signet7-agent"
  installed=1
fi
if [ -f "$SRC/signet7-setup" ]; then
  cp "$SRC/signet7-setup" "$PREFIX/signet7-setup"
  chmod +x "$PREFIX/signet7-setup"
  ln -sfn "$PREFIX/signet7-setup" "$BIN/signet7-setup"
  installed=1
fi

if [ "$installed" -ne 1 ]; then
  echo "This package has no Signet7 app. Unzip the whole folder, then run install.sh from that folder." >&2
  exit 2
fi

if [ -f "$SRC/uninstall.sh" ]; then
  cp "$SRC/uninstall.sh" "$PREFIX/uninstall.sh"
  chmod +x "$PREFIX/uninstall.sh"
fi
echo "Installed Signet7."
echo "Mac may say the app was not opened. The certificate is not finished."
echo "People you email do not install this."
if [ -d "$HOME/Applications/Signet7.app" ]; then
  open "$HOME/Applications/Signet7.app" || true
fi
