#Requires -Version 5.0
$ErrorActionPreference = "Stop"
$Dest = Join-Path $env:LOCALAPPDATA "Signet7"
$Start = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Signet7.lnk"
if (Test-Path $Start) { Remove-Item -Force $Start }
if (Test-Path $Dest) { Remove-Item -Recurse -Force $Dest }
Write-Host "Removed Signet7 from this computer. Mail apps are unchanged."
