Signet7 for windows

This installs the Signet7 app on one office computer.
People you email do not install it.

Right-click install.ps1 and choose Run with PowerShell.
If Windows asks, allow it. The publisher certificate is not finished, so Windows may say the publisher is unknown.

The app is in the Signet7 folder. Leave that folder next to this file until install finishes.
