Signet7 for windows

This installs the Signet7 app on one office computer.
People you email do not install it.

Double-click signet7-setup.exe.
Windows may say the publisher is unknown. The certificate is not finished.

The app is in the Signet7 folder. Leave that folder next to this file until install finishes.
