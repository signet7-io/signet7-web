#Requires -Version 5.0
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $Root "Signet7"
$Dest = Join-Path $env:LOCALAPPDATA "Signet7"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
if (-not (Test-Path (Join-Path $Payload "Signet7.exe"))) {
    Write-Error "This package has no Signet7.exe. Unzip the whole folder, then run install.ps1 from that folder."
}
Copy-Item -Force (Join-Path $Payload "Signet7.exe") (Join-Path $Dest "Signet7.exe")
if (Test-Path (Join-Path $Payload "signet7-agent.exe")) {
    Copy-Item -Force (Join-Path $Payload "signet7-agent.exe") (Join-Path $Dest "signet7-agent.exe")
}
if (Test-Path (Join-Path $Payload "signet7-setup.exe")) {
    Copy-Item -Force (Join-Path $Payload "signet7-setup.exe") (Join-Path $Dest "signet7-setup.exe")
}
$Uninstall = Join-Path $Payload "uninstall.ps1"
if (Test-Path $Uninstall) {
    Copy-Item -Force $Uninstall (Join-Path $Dest "uninstall.ps1")
}
$Wsh = New-Object -ComObject WScript.Shell
$Start = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Signet7.lnk"
$Sc = $Wsh.CreateShortcut($Start)
$Sc.TargetPath = Join-Path $Dest "Signet7.exe"
$Sc.WorkingDirectory = $Dest
$Sc.Save()
Write-Host "Installed $Dest"
Write-Host "Windows may say the publisher is unknown. The certificate is not finished."
Write-Host "People you email do not install this."
Start-Process (Join-Path $Dest "Signet7.exe")
